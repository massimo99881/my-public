##################################################################
					CONFIGURAZIONE AMBIENTE
##################################################################
Sistema Operativo: Windows 7 Professional (32 e 64-bit)
##################################################################
1.Installare Mathematica 8.0.1.0 (prova fatta anche con 10.2.0 Student Edition)
2.Wolfram Workbench v.2.0
2.importare il progetto ISA in Wolfram Workbench
3.Configurare i percorsi di mathematica nella Classe Java "Constants.java"
4.Installare basic-miktex-2.9.5721
5.Installare graphviz-2.38, dopo l'installazione aggiungere alla variabile d'ambiente PATH il percorso: "C:\Program Files (x86)\Graphviz2.38\bin". Poi aprire il prompt dei comandi e digitare "dot --help"
6.Installare python-2.7.10 (per 32 bit) oppure python-2.7.10.amd64 (per 64)
7.Copiare il file "ez_setup.py" nella cartella di python: "C:\Python27"
8.Aprire il prompt dei comandi e andare nella cartella "C:\Python27" ed eseguire il comando "python ez_setup.py"
9.Al termine dell'installazione, sempre dal prompt andare nella cartella "C:\Python27\Scripts" ed eseguire il comando "easy_install dot2tex"
10.Aggiungere alla variabile d'ambiente PATH il percorso: "C:\Python27\Scripts" e dopo aver aperto una nuova finestra del prompt dei comandi digitare: "dot2tex --help"
11.Completare la configurazione dei percorsi definiti nel progetto ISA nella classe java "Constants.java"
12.Eseguire il programma ISA (classe "StartMain.java"), durante la prima esecuzione verr� chiesto di installare le librerie mancanti definite nel template tex
13.Al termine dell'esecuzione verr� aperto il pdf generato
##################################################################
##################################################################

ALTRE INFO UTILI:
Vogliamo stampare grafi come: http://martin-thoma.com/how-to-draw-a-finite-state-machine/

##################################################################
PRIMA PARTE:
##########################################################
vedere documento "installazione.docx" e il sito
http://tex.stackexchange.com/questions/62651/graphviz-and-latex-gives-blank-pdf

Programmi da installare:
-  basic-miktex-2.9.5721.exe
-  graphviz-2.38.msi
-  python-2.7.10.msi
-  ez_setup.py

##########################################################
SECONDA PARTE:
##########################################################
Copy the below script "ez_setup.py" from the below URL

https://bootstrap.pypa.io/ez_setup.py

And copy it into your Python location

C:\Python27>
Run the command

C:\Python27? python ez_setup.py
This will install the easy_install under Scripts directory

C:\Python27\Scripts
Run easy install from the Scripts directory >

C:\Python27\Scripts> easy_install